﻿namespace PortfolioManagement.Models
{

    // NOTE: Generated code may require at least .NET Framework 4.5 or .NET Core/Standard 2.0.
    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
    public partial class Portfolio
    {

        private PortfolioTrade[] tradesField;

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("Trade", IsNullable = false)]
        public PortfolioTrade[] Trades
        {
            get
            {
                return this.tradesField;
            }
            set
            {
                this.tradesField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class PortfolioTrade
    {

        private string tickerField;

        private string tradeDateField;

        private string actionField;

        private byte quantityField;

        private decimal priceField;

        private decimal costField;

        /// <remarks/>
        public string Ticker
        {
            get
            {
                return this.tickerField;
            }
            set
            {
                this.tickerField = value;
            }
        }

        /// <remarks/>
        public string TradeDate
        {
            get
            {
                return this.tradeDateField;
            }
            set
            {
                this.tradeDateField = value;
            }
        }

        /// <remarks/>
        public string Action
        {
            get
            {
                return this.actionField;
            }
            set
            {
                this.actionField = value;
            }
        }

        /// <remarks/>
        public byte Quantity
        {
            get
            {
                return this.quantityField;
            }
            set
            {
                this.quantityField = value;
            }
        }

        /// <remarks/>
        public decimal Price
        {
            get
            {
                return this.priceField;
            }
            set
            {
                this.priceField = value;
            }
        }

        /// <remarks/>
        public decimal Cost
        {
            get
            {
                return this.costField;
            }
            set
            {
                this.costField = value;
            }
        }
    }

}