﻿namespace PortfolioManagement.Models.ViewModel
{
    public class ReportViewModel
    {
        public string Date { get; set; }
        public decimal Price { get; set; }
    }
}
