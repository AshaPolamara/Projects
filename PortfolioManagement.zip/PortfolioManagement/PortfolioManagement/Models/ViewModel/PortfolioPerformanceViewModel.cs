﻿namespace PortfolioManagement.Models.ViewModel
{
    public class PortfolioPerformanceViewModel
    {
        public decimal TotalInvested { get; set; }
        public decimal CurrentIncome { get; set; }
        public decimal PL { get; set; }
        public decimal PLPercent { get; set; }

        public List<PortfolioPLViewModel>? InstrumentsInfo { get; set; }

    }
}
