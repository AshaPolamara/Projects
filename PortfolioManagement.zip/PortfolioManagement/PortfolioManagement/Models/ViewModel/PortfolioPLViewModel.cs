﻿namespace PortfolioManagement.Models.ViewModel
{
    public class PortfolioPLViewModel
    {

        public string Ticker { get; set; }

        public DateTime AsOfDate { get; set; }

        public decimal Cost { get; set; }

        public int Quantity { get; set; }

        public decimal Price { get; set; }

        public decimal MarketValue { get; set; }

        public decimal PrevClose { get; set; }

        public decimal DailyPL { get; set; }

        public decimal InceptionPL { get; set; }

    }

}