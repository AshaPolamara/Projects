﻿using System.Xml.Serialization;

namespace PortfolioManagement.Models
{

    [SerializableAttribute()]
    [XmlTypeAttribute(AnonymousType = true)]
    [XmlRootAttribute(Namespace = "", IsNullable = false)]
    public partial class Portfolio
    {
        [XmlArrayItemAttribute("Trade", IsNullable = false)]
        public PortfolioTrade[] Trades { get; set; }        

        //[System.Xml.Serialization.XmlArrayItemAttribute("PLRecord", IsNullable = false)]
        //public PortfolioPLRecord[] PLReport { get; set; }
          
    }

    [SerializableAttribute()]
    [XmlTypeAttribute(AnonymousType = true)]
    public partial class PortfolioTrade
    {
        public string Ticker { get; set; } = string.Empty;

        public string? TradeDate { get; set; }

        public string? Action { get; set; }

         public int Quantity { get; set; }

        public decimal Price { get; set; }

         public decimal Cost { get; set; }
       
    }
}

