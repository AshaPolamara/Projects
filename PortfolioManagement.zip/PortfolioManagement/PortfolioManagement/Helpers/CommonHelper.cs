﻿using System.Xml.Serialization;

namespace PortfolioManagement.Helpers
{
    public class CommonHelper
    {
        public static T? Deserialize<T>(string xmlString) where T :class 
        {
            XmlSerializer serializer = new XmlSerializer(typeof(T));
            using (Stream reader = new FileStream(xmlString, FileMode.Open))
            {
                return serializer.Deserialize(reader) as T;
            }
        }
    }
}
