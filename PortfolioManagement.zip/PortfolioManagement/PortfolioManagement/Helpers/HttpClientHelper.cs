﻿namespace PortfolioManagement.Helpers
{

    public class HttpClientHelper
    {
        private static readonly HttpClient _httpClient = new HttpClient();

        /// <summary>
        /// Get call to third party api
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static async Task<string> GetAsync(string url)
        {
            using HttpResponseMessage response = await _httpClient.GetAsync(url);

           return await response.Content.ReadAsStringAsync();                     
        }
    }
}
