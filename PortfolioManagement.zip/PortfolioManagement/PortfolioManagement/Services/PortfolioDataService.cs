﻿using PortfolioManagement.Controllers;
using PortfolioManagement.Helpers;
using PortfolioManagement.Models;
using PortfolioManagement.Models.ViewModel;
using System.Text.Json;

namespace PortfolioManagement.Services
{
    public class PortfolioDataService
    {
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _environment;
        private readonly ILogger<PortfolioDataService> _logger;

        public PortfolioDataService(IConfiguration configuration, IWebHostEnvironment environment, ILogger<PortfolioDataService> logger)
        {
            _configuration = configuration;
            _environment = environment;
            _logger = logger;
        }
        /// <summary>
        /// Deserialize xml for ticker details
        /// </summary>
        /// <param name="userId">logged in user</param>
        /// <returns></returns>
        public Portfolio? GetPortfolioData(string userId)
        {
            Portfolio? portfolio = new Portfolio();
            string xmlFileLocation = Path.Combine(_environment.WebRootPath, "Assets", _configuration.GetValue<string>("Xmlfilename"));
            if (!string.IsNullOrWhiteSpace(xmlFileLocation))
            {
                try
                {
                    portfolio = CommonHelper.Deserialize<Portfolio>(xmlFileLocation);
                }
                catch (Exception ex)
                {
                    _logger.LogError("Exception generating portfolio data . Exception : " + ex);
                    throw;
                }
            }
            return portfolio;
        }
        /// <summary>
        /// Generate view model with data for performance view
        /// </summary>
        /// <param name="data">Portfolio data of user</param>
        /// <returns></returns>
        internal PortfolioPerformanceViewModel GeneratedPortfolioPerformanceViewModel(Portfolio data)
        {
            PortfolioPerformanceViewModel ppViewModel = new();

            try
            {
                List<PortfolioPLViewModel> plreports = GeneratePandLReport(data);

                ppViewModel.InstrumentsInfo = plreports;
                ppViewModel.TotalInvested = plreports.Sum(x => x.Cost);
                ppViewModel.CurrentIncome = plreports.Sum(x => x.MarketValue);
                ppViewModel.PL = ppViewModel.CurrentIncome - ppViewModel.TotalInvested;
                ppViewModel.PLPercent = ppViewModel.PL / 100;
            }
            catch (Exception ex)
            {
                _logger.LogError("Exception generating portfolio performance details . Exception : " + ex);
                throw;
            }
            return ppViewModel;
        }

        /// <summary>
        /// Generate profit and loss report
        /// </summary>
        /// <param name="data">portfolio data</param>
        /// <returns></returns>
        private List<PortfolioPLViewModel> GeneratePandLReport( Portfolio data)
        {
            List<PortfolioPLViewModel> plreports = new();

            try
            {
                List<string> tickers = data.Trades.DistinctBy(x => x.Ticker).Select(x => x.Ticker).ToList();

                Dictionary<string, (decimal price, decimal prevClose)> tickerPriceDetails = GenerateTickersLiveDetails(tickers);

                Dictionary<string, List<PortfolioTrade>> holdings = data.Trades.GroupBy(x => x.Ticker)
                                                                  .ToDictionary(group => group.Key, group => group.ToList());

                foreach (KeyValuePair<string, List<PortfolioTrade>> keyValue in holdings)
                {
                    decimal price = tickerPriceDetails.FirstOrDefault(x => x.Key == keyValue.Key).Value.price;
                    decimal prevClose = tickerPriceDetails.FirstOrDefault(x => x.Key == keyValue.Key).Value.prevClose;

                    PortfolioPLViewModel portfolioPLViewModel = new();

                    portfolioPLViewModel.Ticker = keyValue.Key;
                    portfolioPLViewModel.AsOfDate = DateTime.Now;
                    portfolioPLViewModel.Cost = keyValue.Value.Sum(x => x.Cost);
                    portfolioPLViewModel.Quantity = keyValue.Value.Sum(x => x.Quantity);
                    portfolioPLViewModel.Price = price;
                    portfolioPLViewModel.MarketValue = price * portfolioPLViewModel.Quantity;
                    portfolioPLViewModel.PrevClose = prevClose;
                    portfolioPLViewModel.DailyPL = (price - prevClose) * portfolioPLViewModel.Quantity;
                    portfolioPLViewModel.InceptionPL = portfolioPLViewModel.MarketValue - portfolioPLViewModel.Cost;
                    plreports.Add(portfolioPLViewModel);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Exception generating P and L reports data . Exception : " + ex);
                throw;
            }
            return plreports;
        }

        /// <summary>
        /// Generate price and prev close of user tickers
        /// </summary>
        /// <param name="tickers">User tickers</param>
        /// <returns></returns>
        private Dictionary<string, (decimal, decimal)> GenerateTickersLiveDetails(List<string> tickers)
        {

            Dictionary<string, (decimal, decimal)> tickerDetails = new();

            try
            {
                string url = _configuration.GetValue<string>("AlphaVantageSettings:BaseUrl")
                   + "?function=" + _configuration.GetValue<string>("AlphaVantageSettings:function")
                   + "&apikey=" + _configuration.GetValue<string>("AlphaVantageSettings:ApiKey");

                foreach (string ticker in tickers)
                {
                    url = url + "&symbol=" + ticker;
                    tickerDetails.Add(ticker,GetTickerDetails(url, ticker));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Exception generating P and L reports data . Exception : " + ex);
                throw;
            }
            return tickerDetails;
        }

        /// <summary>
        /// Get price and prev close from third party api
        /// </summary>
        /// <param name="url">third party url</param>
        /// <param name="ticker">Name</param>
        /// <returns></returns>
        private (decimal, decimal) GetTickerDetails(string url, string ticker)
        {
           (decimal price, decimal prevClose) tickerDetails = new();
            var quote = HttpClientHelper.GetAsync(url).Result;
            Root? globalQuote = JsonSerializer.Deserialize<Root>(quote);
            if (globalQuote is not null)
            {
                tickerDetails = (Convert.ToDecimal(globalQuote.GlobalQuote.Price), Convert.ToDecimal(globalQuote.GlobalQuote.Previousclose));
            }
            return (tickerDetails);
        }
    }
}
