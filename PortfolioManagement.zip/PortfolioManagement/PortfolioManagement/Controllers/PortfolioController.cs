﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using PortfolioManagement.Models;
using PortfolioManagement.Models.ViewModel;
using PortfolioManagement.Services;
using System.CodeDom.Compiler;

namespace PortfolioManagement.Controllers
{
    public class PortfolioController : Controller
    {
        private readonly PortfolioDataService _portfolioDataService;
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _environment;
        private readonly ILogger<PortfolioController> _logger;
        public PortfolioController(PortfolioDataService portfolioDataService, IConfiguration configuration, IWebHostEnvironment environment, ILogger<PortfolioController> logger)
        {
            _portfolioDataService = portfolioDataService;
            _configuration = configuration;
            _environment = environment;
            _logger = logger;
        }

        public IActionResult PortfolioData()
        {
            try
            {
                Portfolio? data = _portfolioDataService.GetPortfolioData("");
                PortfolioPerformanceViewModel ppviewmodel = new();
                if (data is not null)
                {
                    ppviewmodel = _portfolioDataService.GeneratedPortfolioPerformanceViewModel(data);
                    return View(ppviewmodel);
                }
            }
            catch (Exception) {
                ViewBag.ErrorMessage = "Something went wrong. Please try again after sometime";
            }
            return View();
        }

        public IActionResult Charts(string ticker)
        {
            try
            {
                List<ReportViewModel> lstModel = new List<ReportViewModel>();
                Portfolio? portfolio = _portfolioDataService.GetPortfolioData("");
                if (portfolio is not null)
                {
                    List<PortfolioTrade> data = portfolio.Trades.Where(x => x.Ticker == ticker).ToList();
                    if (data is not null)
                    {
                        foreach (PortfolioTrade item in data)
                        {
                            if (item is not null)
                                lstModel.Add(new ReportViewModel { Date = item.TradeDate ?? string.Empty, Price = item.Price });
                        }
                        ViewBag.Ticker = ticker;
                        return View(lstModel);
                    }
                }
            }
            catch (Exception)
            {
                ViewBag.ErrorMessage = "Something went wrong. Please try again after sometime";
            }
            return View();

        }

    }
}
