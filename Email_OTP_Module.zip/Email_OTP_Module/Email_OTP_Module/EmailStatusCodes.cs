﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Email_OTP_Module
{
    public enum EmailStatusCodes
    {
        STATUS_EMAIL_OK,
        STATUS_EMAIL_FAIL,
        STATUS_EMAIL_INVALID
    }
}
