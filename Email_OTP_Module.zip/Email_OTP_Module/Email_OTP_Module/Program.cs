﻿
using Email_OTP_Module;
#region Generate OTP
Console.WriteLine("Generating OTP!");

Email_OTP eom = new Email_OTP();
EmailStatusCodes emailStatus= eom.Generate_OTP_Email("asha.polamara@.dso.org.sg");
string emailMessage = emailStatus switch
{
    EmailStatusCodes.STATUS_EMAIL_OK => "Email containing OTP has been sent successfully.",
    EmailStatusCodes.STATUS_EMAIL_FAIL => "Email address does not exist or sending to the email has failed.",
    EmailStatusCodes.STATUS_EMAIL_INVALID => "Email address is invalid.",
    _ => "Something went wrong while sending email."
};

Console.WriteLine(emailMessage);
#endregion

#region Check OTP
OTPStatusCodes otpStatus = eom.ReadOtp();

string otpMessage = otpStatus switch
{
    OTPStatusCodes.STATUS_OTP_OK => "OTP is valid and checked.",
    OTPStatusCodes.STATUS_OTP_FAIL => "OTP is wrong after 10 tries.",
    OTPStatusCodes.STATUS_OTP_TIMEOUT => "OTP timeout after 1 min.",
    _ => "Something went wrong while checking otp"
};

Console.WriteLine(otpMessage);
#endregion