﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Email_OTP_Module
{
    internal enum OTPStatusCodes
    {
        STATUS_OTP_OK,
        STATUS_OTP_FAIL,
        STATUS_OTP_TIMEOUT

    }
}
