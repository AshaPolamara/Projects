﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace Email_OTP_Module
{
    internal class Email_OTP
    {
        public readonly string digits;
        public readonly string vaildEmailsFormat;
        string otp = string.Empty;
        int maxRetryCount;
        static int retryCount;

        public Email_OTP()
        {
            digits = "1234567890";
            vaildEmailsFormat = ".dso.org.sg";
            retryCount = 0;
            maxRetryCount = 10;
        }
        /// <summary>
        /// Any start logic
        /// </summary>
        public void Start()
        {
            //create email client
        }
        /// <summary>
        /// Any close logic 
        /// </summary>
        public void Close()
        {
            //Dispose client
        }

        /// <summary>
        /// Generates OTP and send it as email to the input email address
        /// </summary>
        /// <param name="user_email"></param>
        /// <returns> EmailStatusCodes status</returns>
        public EmailStatusCodes Generate_OTP_Email(string user_email)
        {
            if (!user_email.EndsWith(vaildEmailsFormat))
            {
                return EmailStatusCodes.STATUS_EMAIL_INVALID;
            }
            otp = Generate_OTP(6, digits.ToCharArray());

           // Console.WriteLine($"Generated OTP is {otp}");

            string email_body = $"You OTP Code is {otp}. The code is valid for 1 minute";
            bool status = Send_Email(user_email, email_body);

            if (status) return EmailStatusCodes.STATUS_EMAIL_OK;
            else return EmailStatusCodes.STATUS_EMAIL_FAIL;
        }

        /// <summary>
        /// Sends email to user
        /// </summary>
        /// <param name="email_address"></param>
        /// <param name="email_body"></param>
        /// <returns>true/false </returns>
        private bool Send_Email(string email_address, string email_body)
        {
            try
            {
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Errror sending email. Error : {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Generates OTP
        /// </summary>
        /// <param name="otpLength"></param>
        /// <param name="digitChars"></param>
        /// <returns>OTP string</returns>
        private string Generate_OTP(int otpLength, char[] digitChars)
        {

            string otp = String.Empty;

            char val;

            // we can use OTP.net library to generate OTP in a secure way.
            Random rand = new Random();

            for (int i = 0; i < otpLength; i++)
            {
                val = digitChars[rand.Next(0, digitChars.Length)];
                otp += val;
            }

            return otp;
        }

        /// <summary>
        /// Calls check otp and blocks for timeout
        /// </summary>
        /// <returns></returns>
        public OTPStatusCodes ReadOtp()
        {
            Console.WriteLine("Enter OTP sent to your email");

            Task<OTPStatusCodes> task = Task.Run(() => CheckOtp());
            if (task.Wait(TimeSpan.FromSeconds(60)))
                return task.Result;
            else
                return OTPStatusCodes.STATUS_OTP_TIMEOUT;
        }

        /// <summary>
        /// Reads otp and checks till retries is exhausted
        /// </summary>
        /// <returns>OTP status code</returns>
        private OTPStatusCodes CheckOtp()
        {
            string? input = string.Empty;
            while (retryCount < maxRetryCount)
            {
                input = Console.ReadLine();
                if (input is not null && input.Equals(otp))
                {
                    return OTPStatusCodes.STATUS_OTP_OK;
                }
                Console.WriteLine("Invalid OTP.Please try again.");
                retryCount++;
            }
            return OTPStatusCodes.STATUS_OTP_FAIL;
        }
    }
}
