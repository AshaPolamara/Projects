Email OTP Module


Assumption:

1. Send email is not implemented as the requirement asked to assume it is implemented.
2. Didn't use any .net otp libraries assuming Random is simple for assignment purpose.
3. Configuration is hardcoded for now. We need to create appsettings.json and create a host to read configuration.
4. Assuming valid email format is a just the given one. We can make it a list if there are many formats.

Testing:

 Create unit tests for testing the requirement.
 Performance tests with configurable values of timeout.
 Load test to check for memory issues.

How to run:

1.	Download the zip file 
2.	Extract it to a folder.
3.	Navigate to path <<extracted location>>\bin\Debug\.net6
4.	Double click Email_OTP_Module.exe 
